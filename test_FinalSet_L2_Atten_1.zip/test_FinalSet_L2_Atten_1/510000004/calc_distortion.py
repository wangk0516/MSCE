#!/home/kw7rr/anaconda3/bin/python

# ---------- import the python modules ------------------------------------------

from __future__ import division

import numpy as np
import sys
import os
from numpy import linalg as LA

import matplotlib.pyplot as plt

from scipy import interpolate

#################################################################################
# ---------- user defined functions  --------------------------------------------

def RepresentsInt(s):
    try:
        int(s)
        return True
    except ValueError:
        return False

def ReadVASP(fname):
    # open the vasp lattice file
    VASPLATT = open(fname, "r")
    lattice = VASPLATT.readlines()
    VASPLATT.close
    # read the comment line and the scale
    comment = lattice[0]
    scale = lattice[1].split()
    scale = float(scale[0])
    # read the lattice vectors
    vxstr = lattice[2].split()
    vystr = lattice[3].split()
    vzstr = lattice[4].split()
    lattvec = np.zeros([3, 3])
    for II in range(3): lattvec[0, II] = float(vxstr[II])
    for JJ in range(3): lattvec[1, JJ] = float(vystr[JJ])
    for KK in range(3): lattvec[2, KK] = float(vzstr[KK])

    line4th = lattice[5].split()
    if RepresentsInt(line4th[0]) == False:
        WITHLABELS = 1
    elif RepresentsInt(line4th[0]) == True:
        WITHLABELS = 0
    # end of if

    # cases are different with and without atomic labels
    if WITHLABELS == 1:
        atomlist = lattice[4 + WITHLABELS].split()
    else:
        atomlist = []
    # end of if
    atomnumstr = lattice[5 + WITHLABELS].split()
    atomnum = []
    for LL in range(np.size(atomnumstr)):
        atomnum.append(int(atomnumstr[LL]))
    # end of for-LL
    atomnum = np.array(atomnum)

    # get simple atom labels for the case they are missing in POSCAR
    if atomlist == []:
        for CC in range(np.size(atomnum)): atomlist.append("C" + str(CC + 1))
    # end of if

    # read the type of coordinates
    coordtype = lattice[6 + WITHLABELS].split()
    # read the positions of the atoms
    ntot = np.sum(atomnum)
    atompos = np.zeros([ntot, 3])
    for MM in range(ntot):
        linestr = lattice[MM + 7 + WITHLABELS].split()
        for NN in range(3):
            atompos[MM, NN] = float(linestr[NN])
        # end of for-NN
    # end of for-MM
    # define the dictionary for crystal infomation
    crysinfo = {'comment': comment, 'scale': scale, \
            'lattvec': lattvec, 'atomlist': atomlist, \
            'atomnum': atomnum, 'coordtype': coordtype, \
            'atompos': atompos}
    # return the results
    return crysinfo


def calc_displacement_PPP(POS_ini, POS_fin):

    # crystallographic info of the initial lattice
    crysinfo = ReadVASP(POS_ini)
    scale_ini = crysinfo['scale']
    lattvec_ini = crysinfo['lattvec']
    atomlist_ini = crysinfo['atomlist']
    atomnum_ini = crysinfo['atomnum']
    coordtype_ini = crysinfo['coordtype']
    atompos_ini = crysinfo['atompos']

    lattvec_ini = scale_ini*lattvec_ini
    if coordtype_ini[0][0] == 'D' or coordtype_ini[0][0] == 'd':
        atompos_ini = np.matrix(atompos_ini)*np.matrix(lattvec_ini)
    # end of if

    # crystallographic info of the final lattice
    crysinfo = ReadVASP(POS_fin)
    scale_fin = crysinfo['scale']
    lattvec_fin = crysinfo['lattvec']
    atomlist_fin = crysinfo['atomlist']
    atomnum_fin = crysinfo['atomnum']
    coordtype_fin = crysinfo['coordtype']
    atompos_fin = crysinfo['atompos']

    lattvec_fin = scale_fin*lattvec_fin
    if coordtype_fin[0][0] == 'D' or coordtype_fin[0][0] == 'd':
        atompos_fin = np.matrix(atompos_fin)*np.matrix(lattvec_fin)
    # end of if

    atomic_disp = np.zeros([np.size(atompos_ini[:, 0])])
    for K in range(np.size(atompos_ini[:, 0])):
        tempdisp = []
        for aa in [-1, 0, 1]:
            for bb in [-1, 0, 1]:
                for cc in [-1, 0, 1]:
                    temparg = LA.norm(atompos_fin[K, :] + aa*lattvec_fin[0, :] + \
                                bb*lattvec_fin[1, :] + cc*lattvec_fin[2, :] - atompos_ini[K, :])
                    tempdisp.append(temparg)
                # end of for-aa
            # end of for-bb
        # end of for-cc
        atomic_disp[K] = np.amin(np.array(tempdisp))
    # end of for-K

    return atomic_disp


def calc_distortion(POS_ini, POS_fin):

    crysinfo_initial = ReadVASP(POS_ini)
    lattice_initial = crysinfo_initial['scale']*crysinfo_initial['lattvec']

    crysinfo_final = ReadVASP(POS_fin)
    lattice_final = crysinfo_final['scale']*crysinfo_final['lattvec']

    lattice_initial = np.transpose(lattice_initial)/(LA.det(lattice_initial)**(1.0/3))
    lattice_final = np.transpose(lattice_final)/(LA.det(lattice_final)**(1.0/3))

    DIFF = np.matmul(LA.inv(lattice_initial), lattice_final)
    dist_matr = (DIFF + np.transpose(DIFF))/2 - np.identity(3)
    distortion = LA.norm(dist_matr)

    return distortion

def calc_rdf(posname, dr = 0.01, rmax = 15.0, volchg = 'False', vol_ideal = 0):

    crysinfo = ReadVASP(posname)
    scale = crysinfo['scale']
    lattvec = crysinfo['lattvec']
    atomnum = crysinfo['atomnum']
    coordtype = crysinfo['coordtype']
    atompos = crysinfo['atompos']

    lattvec = scale*lattvec
    vol = LA.det(lattvec)

    if volchg == 'True' and vol_ideal > 0:
        Lratio = (vol_ideal/vol)**(1.0/3)
        lattvec = lattvec*Lratio
        atompos = atompos*Lratio
    elif volchg == 'True' and vol_ideal <= 0:
        print('  Wrong values for volchg and vol_ideal. Exit now!')
        sys.exit(1)
    else:
        print('  Volume will not be changed.')
    # end of if

    natom = np.sum(atomnum)
    vol = LA.det(lattvec)
    rho = natom/vol
    print('  Density of atoms (#/A^3): ', rho)

    if coordtype[0][0] == 'C' or coordtype[0][0] == 'c':
        print('  The coordinates is already in cartisian!')
    elif coordtype[0][0] == 'D' or coordtype[0][0] == 'd':
        print('  The fractional coordinates is found!')
        print('  Transformed into cartesian;')
        atompos = np.matrix(atompos)*np.matrix(lattvec)
    # end of if

    r = np.arange(0, rmax, dr) + dr/2
    rdf = np.zeros([np.size(r), 3])

    # find reference coordinates
    center = 0.5*(lattvec[0, :] + lattvec[1, :] + lattvec[2, :])
    pos_ref = atompos - center
    nmid = 0
    distance = 9999.0
    for I in range(np.size(atompos[:, 0])):
        if LA.norm(pos_ref[I, :]) < distance:
            distance = LA.norm(pos_ref[I, :])
            nmid = I
        # end of if
    # end of for-I

    atompos = atompos - atompos[nmid, :]
    for K in range(np.size(r)):
        rdf[K, 0] = r[K]
        for I in range(np.size(atompos[:, 0])):
            if (LA.norm(atompos[I, :]) > r[K] - dr/2) and (LA.norm(atompos[I, :]) < r[K] + dr/2):
                rdf[K, 1] = rdf[K, 1] + 1
            # end of if
        # end of for-I
        rdf[K, 2] = rdf[K, 1]/(rho*4*np.pi*r[K]*r[K]*dr)
    # end of for-K

    return rdf

#################################################################################
# --------- main code -----------------------------------------------------------

if os.path.exists(r'./POSCAR.1'): Initial_POS = "./POSCAR.1"
elif os.path.exists(r'./POSCAR.relax_1'): Initial_POS = "./POSCAR.relax_1"
elif os.path.exists(r'./POSCAR.relax'): Initial_POS = "POSCAR.relax"
else:
    raise ValueError("Initial_POS not given")

distortion = calc_distortion(Initial_POS, 'CONTCAR.static')
print('{0:.6f}'.format(distortion))

#################################################################################

