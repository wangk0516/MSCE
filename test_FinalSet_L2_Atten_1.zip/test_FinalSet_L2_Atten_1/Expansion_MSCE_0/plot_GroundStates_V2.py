
import numpy as np
import os
import sys

import matplotlib as mpl
import matplotlib.pyplot as plt

MAX_FLOAT = sys.float_info.max

large = 30; med = 26; small = 22;
params = {
          'axes.linewidth': '1',
          'xtick.major.size': '15',
          'ytick.major.size': '15',
          'xtick.major.width': '1',
          'ytick.major.width': '1',
          'xtick.minor.size': '7',
          'ytick.minor.size': '7',
          'xtick.minor.width': '1',
          'ytick.minor.width': '1',

          'font.family': ['sans-serif'],
          'font.sans-serif': ['Arial',
                              'DejaVu Sans',
                              'Liberation Sans',
                              'Bitstream Vera Sans',
                              'sans-serif'],

          'axes.titlesize': large,
          'legend.fontsize': small,
          'axes.labelsize': med,
          'axes.titlesize': med,
          'xtick.labelsize': med,
          'ytick.labelsize': med,
          'figure.titlesize': large}

plt.rcParams.update(params)

plt.rcParams.update(params)
plt.rcParams["mathtext.sf"]

# -----------------------------------------------------------------------------

def find_GroundStates(Conc, Energy, StrName, FileName):

    uniq_ConcList = []
    for K in range(len(Conc)):
        if len(uniq_ConcList)  == 0:
            uniq_ConcList.append(Conc[0])
        else:

            exists = False
            for I in range(len(uniq_ConcList)):
                if np.abs(uniq_ConcList[I] - Conc[K]) < 1E-6:
                    exists = True
                    break
                # end if
            if not exists: uniq_ConcList.append(Conc[K])

            # end for-I
        # end if
    # end of for-K
    print("Number of uniq conc: {}".format(len(uniq_ConcList)))
    uniq_ConcList = np.sort(uniq_ConcList)

    uniq_EnergyList = []
    uniq_StrName = []
    for J in range(len(uniq_ConcList)):

        MinEnergy = 1.0
        MinEnergyIndex = 0
        for L in range(len(Energy)):
            if (np.abs(uniq_ConcList[J] - Conc[L]) < 1E-6) and (MinEnergy > Energy[L]):
                MinEnergy = Energy[L]
                MinEnergyIndex = L
            # end if
        # end for-L
 
        uniq_EnergyList.append(MinEnergy)
        uniq_StrName.append(StrName[MinEnergyIndex])
        print(" {:9.6f} {:+9.6E} {}".format(uniq_ConcList[J], MinEnergy, StrName[MinEnergyIndex]))
    # end for-J

    GroundStateStr = []
    GroundStateConc = []
    GroundStateEnergy = []
    GroundStateStr.append(uniq_StrName[0])
    GroundStateConc.append(uniq_ConcList[0])
    GroundStateEnergy.append(uniq_EnergyList[0])
    CurrConc = uniq_ConcList[0]
    CurrEnergy = uniq_EnergyList[0]
    CurrStrName = uniq_StrName[0]
    CurrIndex = 0
    while (uniq_ConcList[-1] - CurrConc > 1E-6):

        slope_info = np.zeros([1, 2])
        for istr in range(CurrIndex + 1, len(uniq_ConcList)):
            temp_slope = (uniq_EnergyList[istr] - CurrEnergy)/(uniq_ConcList[istr] - CurrConc)
            slope_info = np.vstack((slope_info, np.array([temp_slope, istr])))
        # end for-istr
        slope_info = np.delete(slope_info, 0, 0)

        arg = np.argsort(slope_info[:, 0])
        slope_info = slope_info[arg]
        index = int(slope_info[0, 1])

        CurrConc = uniq_ConcList[index]
        CurrEnergy = uniq_EnergyList[index]
        CurrStrName = uniq_StrName[index]
        CurrIndex = index

        GroundStateStr.append(CurrStrName)
        GroundStateConc.append(CurrConc)
        GroundStateEnergy.append(CurrEnergy)

    # end while

    GS_File = open(FileName, "w+")
    for igs in range(len(GroundStateStr)):
        GS_File.write(" {:12.9f} {:>12.9f} {}\n".format(GroundStateConc[igs],
                      GroundStateEnergy[igs], GroundStateStr[igs]))
    GS_File.close()

    return GroundStateConc, GroundStateEnergy, GroundStateStr

# -----------------------------------------------------------------------------

training_file = "MSCE-Alpha-1.000000E+00-Training_WT-0.out"
# training_file = sys.argv[1]

Energy = np.loadtxt(training_file, float, usecols = (2,))
PredEnergy = np.loadtxt(training_file, float, usecols = (3,))

StrName = np.loadtxt(training_file, str, usecols = (-1,))
Conc = np.loadtxt(training_file, float, usecols = (1,))

# Distortion = np.zeros([len(StrName)])
# index_off = []
# index_on = []
# distortion_file = open("distortion.out", "w+")
# for K in range(len(StrName)):
#     Distortion[K] = np.loadtxt("./{}/distortion.out".format(StrName[K]), float)
#     distortion_file.write(" {:>12.9f} {}\n".format(Distortion[K], StrName[K]))
#     if Distortion[K] > 0.1:
#         index_off.append(K)
#     else:
#         index_on.append(K)
#     # end if
# # end for-K
# distortion_file.close()

Distortion = np.loadtxt('distortion.out', float, usecols = (0,))
index_off = []
index_on = []
for K in range(len(StrName)):
    if Distortion[K] > 0.1:
        index_off.append(K)
    else:
        index_on.append(K)
    # end if
# end for-K

gs_conc_DFT, gs_energy_DFT, gs_str_DFT = find_GroundStates(Conc, Energy, StrName, FileName = "GroundStates_EX_DFT.out")
gs_conc_CE, gs_energy_CE, gs_str_CE = find_GroundStates(Conc, PredEnergy, StrName, FileName = "GroundStates_EX_CE.out")

gs_conc_DFT_on, gs_energy_DFT_on, gs_str_DFT_on = find_GroundStates(Conc[index_on], Energy[index_on], StrName[index_on], FileName = "GroundStates_EX_DFT_on-lattice.out")

figsize = [12, 10]
fig, ax = plt.subplots(figsize = figsize)


ax.plot(Conc[index_on], Energy[index_on], 'o', color = 'b', markersize = 10, alpha = 0.75, label = "DFT: $d<0.1$")
ax.plot(gs_conc_DFT_on, gs_energy_DFT_on, '--', lw = 2, color = 'b', markersize = 10, label = "Convex hull: $d<0.1$")

ax.plot(Conc[index_off], Energy[index_off], 'o', color = 'chocolate', markersize = 10, alpha = 0.75, label = "DFT: $d> 0.1$")
ax.plot(gs_conc_DFT, gs_energy_DFT, '-', lw = 2, color = 'r', markersize = 10, label = "Convex hull: All")

ax.plot(Conc, PredEnergy, '+', color = 'r', markersize = 10, markeredgewidth = 1.5, label = "MSCE: All")

structure = '4399'
label = 'C37 Mg$_{2}$Zn'
for K in range(len(StrName)):
    if StrName[K] == structure: break
t = ax.annotate(label, color = 'chocolate', xy=(Conc[K], Energy[K]), xytext = (0.095, -0.09),
    fontsize = 24, arrowprops = dict(arrowstyle = "->", lw = 1.5, color = 'chocolate'))
t.set_bbox(dict(facecolor='white', alpha=0.5, edgecolor='white'))

# structure = '189'
# label = r'P$\bar 1$ MgZn'
# for K in range(len(StrName)):
#     if StrName[K] == structure: break
# t = ax.annotate(label, color = 'k', xy=(Conc[K], Energy[K]), xytext = (0.25, -0.13),
#     fontsize = 24, arrowprops=dict(arrowstyle = "->", lw = 1.5, color = 'k'))
# t.set_bbox(dict(facecolor='white', alpha=0.5, edgecolor='white'))

structure = '44'
label = 'C15 MgZn$_2$'
for K in range(len(StrName)):
    if StrName[K] == structure: break
t = ax.annotate(label, color = 'chocolate', xy=(Conc[K], Energy[K]), xytext = (0.75, -0.15),
    fontsize = 24, arrowprops=dict(arrowstyle = "->", lw = 1.5, color = 'chocolate'))
t.set_bbox(dict(facecolor='white', alpha=0.5, edgecolor='white'))

structure = '510000004'
label = 'C14 MgZn$_2$'
for K in range(len(StrName)):
    if StrName[K] == structure: break
t = ax.annotate(label, color = 'k', xy=(Conc[K], Energy[K]), xytext = (0.66, -0.17),
    fontsize = 24, arrowprops=dict(arrowstyle = "->", lw = 1.5, color = 'k'))
t.set_bbox(dict(facecolor='white', alpha=0.5, edgecolor='white'))

gch = np.loadtxt('MgZn_gch.out', float)
ax.plot(gch[:, 0], gch[:, 1], 'k-o', lw = 3, markersize = 12, label = 'Convex hull: Global')

K = 1
label = 'Mg$_{21}$Zn$_{25}$'
t = ax.annotate(label, color = 'k', xy=(gch[K, 0], gch[K, 1]), xytext = (0.39, -0.15),
    fontsize = 24, arrowprops=dict(arrowstyle = "->", lw = 1.5, color = 'k'))
t.set_bbox(dict(facecolor='white', alpha=0.5, edgecolor='white'))

K = 2
label = 'Mg$_{4}$Zn$_{7}$'
t = ax.annotate(label, color = 'k', xy=(gch[K, 0], gch[K, 1]), xytext = (0.47, -0.17),
    fontsize = 24, arrowprops=dict(arrowstyle = "->", lw = 1.5, color = 'k'))
t.set_bbox(dict(facecolor='white', alpha=0.5, edgecolor='white'))

K = 4
label = 'Mg$_{2}$Zn$_{11}$'
t = ax.annotate(label, color = 'k', xy=(gch[K, 0], gch[K, 1]), xytext = (0.82, -0.105),
    fontsize = 24, arrowprops=dict(arrowstyle = "->", lw = 1.5, color = 'k'))
t.set_bbox(dict(facecolor='white', alpha=0.5, edgecolor='white'))



ax.set_xlim([0, 1])
ax.set_ylim([-0.25, 0.03])

ax.xaxis.set_minor_locator(mpl.ticker.AutoMinorLocator())
ax.yaxis.set_minor_locator(mpl.ticker.AutoMinorLocator())

ax.set_xlabel('Molar fraction of Zn')
ax.set_ylabel('$\Delta E_{f}$ (eV/atom)')

# ax.legend(bbox_to_anchor = (0.43, 0.625, 1.0, 0.4), ncol = 1, fontsize = 24)
ax.legend(loc = 'lower left', ncol = 2, fontsize = 24)
ax.grid()

# -----------------------------------------------------------------------------
# adjust the margins
margins = {  #     vvv margin in inches
    "left"   :     2.0 / figsize[0],
    "bottom" :     1.2 / figsize[1],
    "right"  : 1 - 0.5 / figsize[0],
    "top"    : 1 - 1.3   / figsize[1]
}
fig.subplots_adjust(**margins)

# -----------------------------------------------------------------------------
plt.savefig("MgZn_hull.pdf")
plt.savefig("MgZn_hull.svg")


plt.show()




