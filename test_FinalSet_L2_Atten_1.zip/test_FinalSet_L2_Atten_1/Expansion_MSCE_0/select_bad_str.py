
import numpy as np
import sys

count = sys.argv[1]

error_list = np.loadtxt("MSCE-Alpha-1.000000E+00-Training_WT-{}.out".format(count), float, usecols = (5,))
str_list = np.loadtxt("MSCE-Alpha-1.000000E+00-Training_WT-{}.out".format(count), str, usecols = (-1,))

print("RMSE of fitting: {:>12.9f}".format(np.sqrt(np.mean(error_list**2))))

for K in range(len(error_list)):
    if np.abs(error_list[K]) > 0.003:
        print(" {:>16.9f} {}".format(error_list[K], str_list[K]))


