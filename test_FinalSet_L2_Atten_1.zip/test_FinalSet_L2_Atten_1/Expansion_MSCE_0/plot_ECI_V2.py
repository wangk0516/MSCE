
#!/home/kw7rr/anaconda3/bin/python

# ---------- import the python modules ----------------------------------------

from __future__ import division

import numpy as np
from numpy import linalg as LA

import sys
import os

import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec

# ---------- Import modules in kwlib ------------------------------------------

sys.path.append("/sfs/qumulo/qhome/kw7rr/msce_scripts")
from cluster_utils import read_cluster_info

# -----------------------------------------------------------------------------

large = 24; med = 20; small = 16;
params = {
          'axes.linewidth': '1',
          'xtick.major.size': '6',
          'ytick.major.size': '6',
          'xtick.major.width': '1',
          'ytick.major.width': '1',
          'xtick.minor.size': '3',
          'ytick.minor.size': '3',
          'xtick.minor.width': '0.5',
          'ytick.minor.width': '0.5',

          'font.family': ['sans-serif'],
          'font.sans-serif': ['Arial',
                              'DejaVu Sans',
                              'Liberation Sans',
                              'Bitstream Vera Sans',
                              'sans-serif'],

          'axes.titlesize': large,
          'legend.fontsize': med,
          'axes.labelsize': med,
          'axes.titlesize': med,
          'xtick.labelsize': small,
          'ytick.labelsize': small,
          'figure.titlesize': large}

plt.rcParams.update(params)

# -----------------------------------------------------------------------------

# cluster_file = sys.argv[1]
# eci_file = sys.argv[2]

cluster_file = 'clusters.out'
eci_file = 'MSCE-Alpha-1.000000E+00-ECI_WT-0.out'

print("  Name of cluster file: {}".format(cluster_file))
print("  Name of ECI file: {}\n".format(eci_file))

ClusterCollection = read_cluster_info(filename = cluster_file)
NumClusters = ClusterCollection['NumClusters']
ClusterInfo = ClusterCollection['ClusterInfo']
MaxDiameter = ClusterCollection['MaxDiameter']

print("  Numbers of pairs, triplets, quaduplets, site-5 and site-6 clusters: {}, {}, {}, {}, {}".format(NumClusters[2],
      NumClusters[3], NumClusters[4], NumClusters[5], NumClusters[6]))
print("  Total number of clusters: {}".format(np.sum(NumClusters)))
print("  Shape of ClusterInfo: {}".format(np.shape(ClusterInfo)))

ECI = np.loadtxt(eci_file, float)
print("  Number of ECIs: {}\n".format(len(ECI)))

ECI[:] = ECI[:]*1000

# for K in range(len(ECI)):
#     print("  {:>4d} {:>2.0f} {:>9.6f} {:>15.12f}".format(K, ClusterInfo[K, 2], ClusterInfo[K, 1], ECI[K]))
# # end for-K
# print("")

ECI_max = np.amax(ECI[2:])
ECI_min = np.amin(ECI[2:])
print("  ECI_min, ECI_max = {:>15.12f} {:>15.12f}\n".format(ECI_min, ECI_max))

# -----------------------------------------------------------------------------

figsize = (14, 7)
fig, ax = plt.subplots(figsize = figsize)

max_index = np.zeros([7], dtype = int)
max_rcut = np.zeros([7])
for K in range(len(ClusterInfo[:, 0])):
    print("{:>3d} {:4.0f} {:12.6f} {:4.0f} {:>9.6f}".format(K,
                                                          ClusterInfo[K, 0],
                                                          ClusterInfo[K, 1],
                                                          ClusterInfo[K, 2],
                                                          ECI[K]))
    if ClusterInfo[K, 2] == 2:
        ax.bar(K, ECI[K], align = 'center', color = 'b', alpha = 0.75, width = 0.9)
        max_index[2] = K
        max_rcut[2] = ClusterInfo[K, 1]
    elif ClusterInfo[K, 2] == 3:
        ax.bar(K, ECI[K], align = 'center', color = 'r', alpha = 0.75, width = 0.9)
        max_index[3] = K
        max_rcut[3] = ClusterInfo[K, 1]
    elif ClusterInfo[K, 2] == 4:
        ax.bar(K, ECI[K], align = 'center', color = 'g', alpha = 0.75, width = 0.9)
        max_index[4] = K
        max_rcut[4] = ClusterInfo[K, 1]
    elif ClusterInfo[K, 2] == 5:
        ax.bar(K, ECI[K], align = 'center', color = 'chocolate', alpha = 0.75, width = 0.9)
        max_index[5] = K
        max_rcut[5] = ClusterInfo[K, 1]
    elif ClusterInfo[K, 2] == 6:
        ax.bar(K, ECI[K], align = 'center', color = 'm', alpha = 0.75, width = 0.9)
        max_index[6] = K
        max_rcut[6] = ClusterInfo[K, 1]

K = max_index[2]
ax.bar(K, ECI[K], align = 'center', color = 'b', alpha = 0.75, width = 0.9, label = '2-body')
K = max_index[3]
ax.bar(K, ECI[K], align = 'center', color = 'r', alpha = 0.75, width = 0.9, label = '3-body')
K = max_index[4]
ax.bar(K, ECI[K], align = 'center', color = 'g', alpha = 0.75, width = 0.9, label = '4-body')
K = max_index[5]
ax.bar(K, ECI[K], align = 'center', color = 'chocolate', alpha = 0.75, width = 0.9, label = '5-body')
K = max_index[6]
ax.bar(K, ECI[K], align = 'center', color = 'm', alpha = 0.75, width = 0.9, label = '6-body')

xline = np.linspace(-2, max_index[6] + 2, 101)
yline = np.zeros(np.shape(xline))
ax.plot(xline, yline, '-', color = 'k', lw = 0.5)

nsite = 2
yline = np.linspace(-10, 10, 101)
xline = (max_index[nsite] + 0.5)*np.ones(np.shape(yline))
ax.plot(xline, yline, '-.', color = 'k', lw = 0.5)
nsite = 3
yline = np.linspace(-10, 10, 101)
xline = (max_index[nsite] + 0.5)*np.ones(np.shape(yline))
ax.plot(xline, yline, '-.', color = 'k', lw = 0.5)
nsite = 4
yline = np.linspace(-10, 10, 101)
xline = (max_index[nsite] + 0.5)*np.ones(np.shape(yline))
ax.plot(xline, yline, '-.', color = 'k', lw = 0.5)

nsite = 2
t = ax.annotate("$r_{2}^{cut}$" + " = {:.2f} $\AA$".format(ClusterInfo[max_index[nsite], 1]), 
                color = 'k', xy=(max_index[nsite] + 0.5, -10), xytext = (max_index[nsite] - 105, -7.5),
                fontsize = 18, arrowprops = dict(arrowstyle = "->", lw = 1.5, color = 'k'))
t.set_bbox(dict(facecolor='white', alpha=0.5, edgecolor='white'))

nsite = 3
t = ax.annotate("$r_{3}^{cut}$" + " = {:.2f} $\AA$".format(ClusterInfo[max_index[nsite], 1]), 
                color = 'k', xy=(max_index[nsite] + 0.5, -10), xytext = (max_index[nsite] - 95, -7.5),
                fontsize = 18, arrowprops = dict(arrowstyle = "->", lw = 1.5, color = 'k'))
t.set_bbox(dict(facecolor='white', alpha=0.5, edgecolor='white'))

nsite = 4
t = ax.annotate("$r_{4}^{cut}$" + " = {:.2f} $\AA$".format(ClusterInfo[max_index[nsite], 1]), 
                color = 'k', xy=(max_index[nsite] + 0.5, -10), xytext = (max_index[nsite] - 95, -7.5),
                fontsize = 18, arrowprops = dict(arrowstyle = "->", lw = 1.5, color = 'k'))
t.set_bbox(dict(facecolor='white', alpha=0.5, edgecolor='white'))

ax.set_xlim([-2, max_index[6] + 2])
# ax.set_ylim([ECI_min - 0.02*(ECI_max - ECI_min), ECI_max + 0.02*(ECI_max - ECI_min)])
ax.set_ylim([-10, 10])

ax.set_xlabel("Clusters with increasing diameters")
ax.set_ylabel("ECI (meV/atom)")

# ax.grid()
ax.legend(loc = 'upper left', ncol = 2)

# -----------------------------------------------------------------------------
# adjust the margins
margins = {  #     vvv margin in inches
    "left"   :     1.5 / figsize[0],
    "bottom" :     1.5 / figsize[1],
    "right"  : 1 - 0.5 / figsize[0],
    "top"    : 1 - 1   / figsize[1]
}
fig.subplots_adjust(**margins)
#################################################################################

plt.savefig('ECI_{}.pdf'.format(23456))
plt.savefig('ECI_{}.svg'.format(23456))

plt.show()



