

import numpy as np
import numpy.linalg as LA

folders = np.loadtxt("allstrnames.out", str)

for I in range(len(folders)):
    for J in range(I + 1, len(folders)):
        cf_II = np.loadtxt("{}/correlations.out".format(folders[I]), float)
        cf_JJ = np.loadtxt("{}/correlations.out".format(folders[J]), float)

        if LA.norm(cf_II - cf_JJ) < 1E-3:
            print("same structures: {} {}".format(folders[I], folders[J]))


