

import numpy as np

CV = np.loadtxt("DATASET_CV.OUT", float, usecols = (4,))
print("Averaged CV (eV/atom): {:>16.9f}".format(np.mean(np.abs(CV))))
print("MSE CV (eV/atom): {:>16.9f}".format(np.sqrt(np.mean(CV**2))))

