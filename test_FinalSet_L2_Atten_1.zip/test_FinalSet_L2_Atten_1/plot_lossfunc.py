
#!/home/kw7rr/anaconda3/bin/python

# ---------- import the python modules ----------------------------------------

from __future__ import division

import numpy as np
from numpy import linalg as LA

import sys
import os

import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec

# ---------- Import modules in kwlib ------------------------------------------

sys.path.append("/sfs/qumulo/qhome/kw7rr/msce_scripts")
from cluster_utils import read_cluster_info

# -----------------------------------------------------------------------------

large = 24; med = 20; small = 16;
params = {
          'axes.linewidth': '1',
          'xtick.major.size': '6',
          'ytick.major.size': '6',
          'xtick.major.width': '1',
          'ytick.major.width': '1',
          'xtick.minor.size': '3',
          'ytick.minor.size': '3',
          'xtick.minor.width': '0.5',
          'ytick.minor.width': '0.5',

          'font.family': ['sans-serif'],
          'font.sans-serif': ['Arial',
                              'DejaVu Sans',
                              'Liberation Sans',
                              'Bitstream Vera Sans',
                              'sans-serif'],

          'axes.titlesize': large,
          'legend.fontsize': med,
          'axes.labelsize': med,
          'axes.titlesize': med,
          'xtick.labelsize': small,
          'ytick.labelsize': small,
          'figure.titlesize': large}

plt.rcParams.update(params)

# -----------------------------------------------------------------------------

figsize = (14, 7)
fig, ax = plt.subplots(figsize = figsize)

lossfunc = np.loadtxt('lossfunc.out', float, usecols = (2,))

ax.plot(lossfunc, 'b-', label = 'LBFGS: MSCE-L2')

# ax.set_xlim([-2, max_index[6] + 2])
# ax.set_ylim([ECI_min - 0.02*(ECI_max - ECI_min), ECI_max + 0.02*(ECI_max - ECI_min)])
# ax.set_ylim([-10, 10])

ax.set_yscale('log')

ax.set_xlabel("Number of iternations")
ax.set_ylabel("Loss function (eV/cell)")

ax.grid()
ax.legend(loc = 'upper left', ncol = 2)

# -----------------------------------------------------------------------------
# adjust the margins
margins = {  #     vvv margin in inches
    "left"   :     1.5 / figsize[0],
    "bottom" :     1.5 / figsize[1],
    "right"  : 1 - 0.5 / figsize[0],
    "top"    : 1 - 1   / figsize[1]
}
fig.subplots_adjust(**margins)
#################################################################################

plt.show()



