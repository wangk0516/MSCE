
import numpy as np
import scipy.optimize as optimization

import sys

# ---------- Import modules in kwlib ------------------------------------------

sys.path.append("/home/kw7rr/bin/kwlib/msce")
from cse_utils import generate_CSE_surf
from cse_utils import plot_fitted_CSE_surf

# -----------------------------------------------------------------------------


# 7th
# atten_coeffs = [ 0.73246275, -1.36444627,  0.00184851,  0.38919899,  0.26535703,  0.0288717, 0.23899614]

# 9th
# atten_coeffs = [ 0.76409269, -1.61534481,  0.32476936,  0.47548501,  0.52003314, -0.14902567, -0.06811906]

# 12th
# atten_coeffs = [ 0.7183884,  -1.36094072,  0.02554705,  0.4782395,   0.33849512,  0.22513073, 0.43971164]

# 13th
# atten_coeffs = [ 0.73246868, -1.36446203,  0.0018504,   0.38919966,  0.26608989,  0.22514123, 0.43972525]

# 14th
# atten_coeffs = [ 0.7067161,  -1.3476978, 0.08875912,  0.52677264,  0.33849958,  0.22514123, 0.43972525]

# 15th
# atten_coeffs = [ 0.1014139,  -1.12612408,  0.49299804,  0.39721916,  0.60075346,  0.14421302, 0.33078723]

"""
atten_coeffs = [1.725269938166E+00,
    1.051406204450E+00,
    1.122532587586E+00,
    9.203940091463E-01,
    8.870537104361E-01,
    1.076755179420E+00,
    1.086789676572E+00]

atten_coeffs = [ +2.096715831005E+00,
 +1.065207717436E+00,
 +9.589355543908E-01,
 +1.046859073891E+00,
 +1.093790622969E+00,
 +1.051786037044E+00,
 +1.228006623349E+00]
"""

# atten_coeffs = np.zeros([7])
# atten_coeffs[0] = +2.096715831005E+00

atten_coeffs = np.loadtxt("MSCE-Alpha-1.000000E+00-Atten_WT-0.out", float)

syminfo = 'hex'


phi_mesh, theta_mesh, rho_mesh = generate_CSE_surf(atten_coeffs, syminfo)

rho_mesh = np.power(rho_mesh, 2)

plot_fitted_CSE_surf(phi_mesh, theta_mesh, rho_mesh, filename = 'attenuation')


